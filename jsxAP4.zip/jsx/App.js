import { StyleSheet, Text, View } from 'react-native';

// You can import supported modules from npm
import { Card, TextInput,Button } from 'react-native-paper';

// or any files within the Snack
import AssetExample from './components/AssetExample';
const isAdmin=true;
const estilo='florida';
const colorPlaceholder = estilo === 'florida' ? 'white' : 'orange';
const modulos2Dam = [
{ nombre: 'DIN', profesor: 'Manel', horas: 120 },
{ nombre: 'ADA', profesor: 'Juanmi', horas: 120 },
{ nombre: 'PMDM', profesor: 'Fran', horas: 100 },
{ nombre: 'PSP', profesor: 'Fran', horas: 60 },
{ nombre: 'SGE', profesor: 'Belén', horas: 100 },
{ nombre: 'Inglés', profesor: 'Caterina', horas: 40 },
{ nombre: 'EIE', profesor: 'Manuel', horas: 60 },
];
function Modulos() {
  return (
    <View>
      {modulos2Dam.map((modulo, index) => (
        <View
          key={index}
          style={{
            backgroundColor: index % 2 === 0 ? '#F48FB1' : '#F8BBD0',
            padding: 10,
          }}
        >
          <Text>{index + 1}</Text>
          <Text>{modulo.nombre}</Text>
          <Text>{modulo.profesor}</Text>
          <Text>{modulo.horas} horas</Text>
        </View>
      ))}
    </View>
  );
}


function BotonInformes(){
  return(
    isAdmin ?(
      <View>
      <Button icon="format-list-bulleted"
      mode="contained">
      INFORMES
      </Button>
      </View>
    ):null
  );
}
function nombre() {
  return (
    <View>
       <Text style={styles.upv}>Neus Bataller</Text>
    </View>
  );
}
function datos() {
  return (
   <View  style={styles[estilo]}>
      <TextInput
        label="Nombre"
        placeholder="Introduce tus datos"
        placeholderTextColor={colorPlaceholder}
        left={<TextInput.Icon icon="eye" />}
      />

      <TextInput
       label="Módulo"
        placeholder="Introduce tus datos"
        placeholderTextColor={colorPlaceholder}
        left={<TextInput.Icon icon="eye" />}
      />
    </View>
  );
}
export default function App() {
  return (
    <View>
      {nombre()}
      {datos()}
      <BotonInformes />
      <Modulos />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  upv: {
backgroundColor: 'purple',
fontSize: 10,
fontWeight: '600',
padding: 4,
paddingLeft: 12,
textAlign: 'left',
color: 'grey',
},
florida: {
backgroundColor: 'red',
fontSize: 12,
fontWeight: '600',
padding: 4,
paddingRight: 12,
textAlign: 'right',
},

});
